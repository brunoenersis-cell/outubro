import { cookies } from "next/headers";
import { adminPassword, sessionValue } from "@/lib/admin";
export async function POST(request:Request){const {password}=await request.json() as {password?:string};if(!adminPassword()||password!==adminPassword())return Response.json({error:"Palavra-passe inválida."},{status:401});const store=await cookies();store.set("escala_admin",await sessionValue(),{httpOnly:true,secure:true,sameSite:"strict",path:"/",maxAge:43200});return Response.json({ok:true})}
