import { cookies } from "next/headers";
import { asc } from "drizzle-orm";
import { getDb } from "@/db"; import { availability } from "@/db/schema"; import { isAdmin } from "@/lib/admin";
export async function GET(){const token=(await cookies()).get("escala_admin")?.value;if(!await isAdmin(token))return Response.json({error:"Não autorizado."},{status:401});const rows=await getDb().select().from(availability).orderBy(asc(availability.serviceDate),asc(availability.person));return Response.json({rows})}
