# Escala Outubro

Aplicação para recolher disponibilidade da equipa e gerir a escala.

## Executar localmente

1. Instale as dependências com `npm install`.
2. Crie um ficheiro `.env` a partir de `.env.example` e escolha credenciais fortes.
3. Gere a migração da base de dados com `npx drizzle-kit generate` e aplique-a no ambiente de alojamento.
4. Inicie a aplicação com `npm run dev`.

## Administração

Aceda a `/admin`. A palavra-passe e a chave de sessão são variáveis secretas do alojamento: nunca devem ser colocadas no código nem partilhadas com os utilizadores.
