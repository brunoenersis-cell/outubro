CREATE TABLE `availability` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `person` text NOT NULL,
  `service_date` text NOT NULL,
  `service_type` text NOT NULL,
  `is_available` integer NOT NULL,
  `responded_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
CREATE UNIQUE INDEX `availability_person_date_unique` ON `availability` (`person`,`service_date`);
CREATE INDEX `idx_availability_date` ON `availability` (`service_date`);
