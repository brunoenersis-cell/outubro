import { env } from "cloudflare:workers";
const encoder=new TextEncoder();
async function sign(value:string){const key=await crypto.subtle.importKey("raw",encoder.encode(env.ADMIN_SESSION_SECRET||""),{name:"HMAC",hash:"SHA-256"},false,["sign"]);const sig=await crypto.subtle.sign("HMAC",key,encoder.encode(value));return btoa(String.fromCharCode(...new Uint8Array(sig))).replaceAll("+","-").replaceAll("/","_").replaceAll("=","")}
export async function sessionValue(){const value=`admin.${Math.floor(Date.now()/1000)+60*60*12}`;return `${value}.${await sign(value)}`}
export async function isAdmin(token?:string){if(!token||!env.ADMIN_SESSION_SECRET)return false;const [kind,expires,signature]=token.split(".");if(kind!=="admin"||!expires||!signature||Number(expires)<Date.now()/1000)return false;const expected=await sign(`${kind}.${expires}`);return signature===expected}
export function adminPassword(){return env.ADMIN_PASSWORD||""}
